package com.lab7.exercises;

public class ConcatetwoStringd {

	public static void main(String[] args) {
		
		String str1="Hellow";
		String str2="World";
		String str3=str1.concat(str2);
		
		System.out.println(str3);

	}

}
